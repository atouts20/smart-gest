package bj.prexed.succursaleservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuccursaleserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
