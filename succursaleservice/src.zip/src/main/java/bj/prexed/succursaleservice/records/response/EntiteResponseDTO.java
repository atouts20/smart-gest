package bj.prexed.succursaleservice.records.response;

public record EntiteResponseDTO(
        String id,
          String sigle
        , String raisociale
        , String email
        , boolean enabled
        , String verificaToken
        , boolean deleted
        , String urllogo
        , String slogan
        , String domaineweb
) { }
