package bj.prexed.succursaleservice.records.response;

import bj.prexed.succursaleservice.entities.Succursale;

public record DivisionResponseDTO(String id,String lblDivision, String description, Succursale succursale) {
}
