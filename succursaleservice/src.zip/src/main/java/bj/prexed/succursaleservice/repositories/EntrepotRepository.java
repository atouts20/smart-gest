package bj.prexed.succursaleservice.repositories;

import bj.prexed.succursaleservice.entities.Agence;
import bj.prexed.succursaleservice.entities.Division;
import bj.prexed.succursaleservice.entities.Entrepot;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface EntrepotRepository extends JpaRepository<Entrepot, String> {

    Iterable<Entrepot> findByAgence(Agence d);

    Page<Entrepot> findByLblEntrepot(String d, Pageable p);
}
