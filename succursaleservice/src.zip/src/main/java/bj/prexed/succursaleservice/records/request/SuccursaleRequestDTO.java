package bj.prexed.succursaleservice.records.request;

public record SuccursaleRequestDTO(
        String lblSuccursale
        , String formeJuridique
        , String ville
        , String pays
        , String type
        , String portable
        , String telephone
        , String adresse
        , String email

) { }
