package bj.prexed.succursaleservice.records.request;

public record EntiteRequestDTO(
        String sigle
        , String raisociale
        , String email
        , boolean enabled
        , String verificaToken
        , boolean deleted
        , String urllogo
        , String slogan
        , String domaineweb
) { }
