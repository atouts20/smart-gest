package bj.prexed.succursaleservice.mappers;

import bj.prexed.succursaleservice.entities.Succursale;
import bj.prexed.succursaleservice.records.request.SuccursaleRequestDTO;
import bj.prexed.succursaleservice.records.response.SuccursaleResponseDTO;
import org.mapstruct.Mapper;
import org.springframework.data.domain.Page;

import java.util.Optional;

@Mapper(componentModel = "spring")
public interface SuccursaleMapper{
    Succursale succursaleRequestDTOSuccursale(SuccursaleRequestDTO succursaleRequestDTO);
    SuccursaleResponseDTO succursaleTOSuccursaleResponseDto(Succursale succursale);

}
