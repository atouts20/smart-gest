package bj.prexed.succursaleservice.services;

import bj.prexed.succursaleservice.entities.Entite;
import bj.prexed.succursaleservice.mappers.EntiteMapper;
import bj.prexed.succursaleservice.records.request.EntiteRequestDTO;
import bj.prexed.succursaleservice.records.response.EntiteResponseDTO;
import bj.prexed.succursaleservice.repositories.EntiteRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class EntiteService {
}
