package bj.prexed.succursaleservice.entities;


import bj.prexed.succursaleservice.enums.FormeJuridique;
import bj.prexed.succursaleservice.enums.TypeStructure;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.Email;

@Entity
@Data
@AllArgsConstructor @NoArgsConstructor @Builder
public class Succursale {

    @Id
    private String id;

    @Column(nullable = false)
    private String lblSuccursale;

    @Enumerated
    private FormeJuridique formeJuridique = FormeJuridique.ETS;

    @Column(nullable = false)
    private String ville, pays;

    @Enumerated
    private TypeStructure type = TypeStructure.Agroalimentaire;

    @Basic
    private String portable, telephone, adresse;

    @Email
    private String email;

    @ManyToOne
    private Entite entite;

}
