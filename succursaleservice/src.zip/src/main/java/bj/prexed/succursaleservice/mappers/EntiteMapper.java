package bj.prexed.succursaleservice.mappers;

import bj.prexed.succursaleservice.entities.Entite;
import bj.prexed.succursaleservice.records.request.EntiteRequestDTO;
import bj.prexed.succursaleservice.records.response.EntiteResponseDTO;
import org.mapstruct.Mapper;
import org.springframework.data.domain.Page;


@Mapper(componentModel = "spring")
public interface EntiteMapper {
    Entite entiteRequestDTOEntite(Entite entite);
    EntiteResponseDTO entiteToEntiteResponseDTO(EntiteResponseDTO entiteResponseDTO);
}
