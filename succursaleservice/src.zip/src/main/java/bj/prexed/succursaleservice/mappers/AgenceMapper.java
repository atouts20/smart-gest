package bj.prexed.succursaleservice.mappers;

import bj.prexed.succursaleservice.entities.Agence;
import bj.prexed.succursaleservice.records.request.AgenceRequestDTO;
import bj.prexed.succursaleservice.records.response.AgenceResponseDTO;
import org.mapstruct.Mapper;
import org.springframework.data.domain.Page;

@Mapper(componentModel = "spring")
public interface AgenceMapper {
    Agence agenceRequestDTOAgence(AgenceRequestDTO agenceRequestDTO);
    AgenceResponseDTO agenceToAgenceResponseDTO( Page<AgenceResponseDTO> agence);
}
