package bj.prexed.succursaleservice.records.response;

import bj.prexed.succursaleservice.entities.Agence;

public record EntrepotResponsetDTO(String id, String reference, String lblEntrepot, String telephone, String type, boolean initialised, Agence agence) {
}
