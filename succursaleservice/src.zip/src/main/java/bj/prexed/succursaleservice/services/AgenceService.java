package bj.prexed.succursaleservice.services;

import bj.prexed.succursaleservice.entities.Agence;
import bj.prexed.succursaleservice.entities.Division;
import bj.prexed.succursaleservice.entities.Succursale;
import bj.prexed.succursaleservice.mappers.AgenceMapper;
import bj.prexed.succursaleservice.records.response.AgenceResponseDTO;
import bj.prexed.succursaleservice.repositories.AgenceRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AgenceService {

    private final AgenceRepository repository;
    private final AgenceMapper mapper;


    public AgenceService(AgenceRepository repository, AgenceMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }

    /*public AgenceResponseDTO add( Agence agence) {
        return mapper.agenceToAgenceResponseDTO (repository.save(agence));
    }


    public Page<AgenceResponseDTO> allbyDivision(Division s, Pageable page) {
        return  mapper.agenceToAgenceResponseDTO( repository.findByDivision (s, page));
    }

    public Page<AgenceResponseDTO> allbySuccursale(String s, Pageable page) {
        return  mapper.agenceToAgenceResponseDTO(
                repository.findByLblAgence (s, page)
        );
    }*/

    /*public  AgenceResponseDTO one(String  id) {
        return mapper.agenceToAgenceResponseDTO(
                repository.findById(id).get()
        );
    }*/

//    public Optional<Agence> set(Long id, Agence agence) {
//        return one(id).map(e -> {
//            e.setLibelle(agence.getLibelle());
//            e.setTelephone(agence.getTelephone());
//            e.setRegions(agence.getRegions());
//            e.setAdresse(agence.getAdresse());
//            e.setKtier(agence.getKtier());
//            e.setPosition(agence.getPosition());
//            e.setReference(agence.getReference());
//            e.setType(agence.getType());
//            return repository.save(e);
//        });
//    }

//    public Optional<Agence> del(Long id) {
//        return one(id).map(agence -> {
//            repository.delete(agence);
//            return agence;
//        });
//    }

}
