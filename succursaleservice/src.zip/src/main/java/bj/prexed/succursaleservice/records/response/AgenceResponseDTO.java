package bj.prexed.succursaleservice.records.response;

public record AgenceResponseDTO(String id, String refAgence, String lblAgence, String telephone, String adresse, String division, String ktierId) {
}
