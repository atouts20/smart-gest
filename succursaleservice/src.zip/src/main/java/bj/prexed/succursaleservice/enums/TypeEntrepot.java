package bj.prexed.succursaleservice.enums;

public enum TypeEntrepot {
    Magasin
    ,Entrepot
    ,Commercial
}
