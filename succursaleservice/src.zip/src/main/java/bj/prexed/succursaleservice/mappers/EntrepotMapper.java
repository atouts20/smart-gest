package bj.prexed.succursaleservice.mappers;

import bj.prexed.succursaleservice.entities.Entrepot;
import bj.prexed.succursaleservice.entities.dto.resquest.EntrepotRequestDTO;
import bj.prexed.succursaleservice.records.response.EntrepotResponsetDTO;
import org.mapstruct.Mapper;
import org.springframework.data.domain.Page;

import java.util.Optional;


@Mapper(componentModel = "spring")
public interface EntrepotMapper {
    Entrepot entrepotRequestDTOEntrepot( EntrepotRequestDTO entrepotRequestDTO );
    EntrepotResponsetDTO entrepotToEntrepotResponseDTO(Entrepot entrepot);

}
