package bj.prexed.succursaleservice.services;

import bj.prexed.succursaleservice.entities.Division;
import bj.prexed.succursaleservice.entities.Entrepot;
import bj.prexed.succursaleservice.mappers.EntrepotMapper;
import bj.prexed.succursaleservice.records.request.EntiteRequestDTO;
import bj.prexed.succursaleservice.records.request.EntrepotRequestDTO;
import bj.prexed.succursaleservice.records.response.EntrepotResponsetDTO;
import bj.prexed.succursaleservice.repositories.EntrepotRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class EntrepotService {
}
