package bj.prexed.succursaleservice.records.request;

import bj.prexed.succursaleservice.entities.Succursale;

public record DivisionRequestDTO(String lblDivision, String description, Succursale succursale) {
}
