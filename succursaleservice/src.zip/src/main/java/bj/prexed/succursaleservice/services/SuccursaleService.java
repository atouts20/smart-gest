package bj.prexed.succursaleservice.services;


import bj.prexed.succursaleservice.entities.Entite;
import bj.prexed.succursaleservice.entities.Succursale;
import bj.prexed.succursaleservice.mappers.SuccursaleMapper;
import bj.prexed.succursaleservice.records.request.SuccursaleRequestDTO;
import bj.prexed.succursaleservice.records.response.SuccursaleResponseDTO;
import bj.prexed.succursaleservice.repositories.SuccursaleRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class SuccursaleService {

}
