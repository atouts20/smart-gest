package bj.prexed.succursaleservice.entities;


import bj.prexed.succursaleservice.enums.TypeEntrepot;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
//@Table(indexes = {@Index(columnList = "lblEntrepot")}, uniqueConstraints = {@UniqueConstraint(columnNames = {"lbl_entrepot", "agence_id"})})
public class Entrepot {

    @Id
    private String id;

    @Column(length = 10)
    private String reference;

    //@Column(nullable = false)
    private String lblEntrepot;

    @Column
    private String  telephone;

    @Enumerated
    private TypeEntrepot type = TypeEntrepot.Entrepot;

    @Basic
    private Boolean initialised; // cuivre = societe pétrolière

    @ManyToOne
    @JoinColumn(name="agence_id", nullable=false)
    private Agence agence;
}
