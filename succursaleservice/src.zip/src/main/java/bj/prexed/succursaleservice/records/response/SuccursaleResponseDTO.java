package bj.prexed.succursaleservice.records.response;

public record SuccursaleResponseDTO(
        String id
        , String lblSuccursale
        , String formeJuridique
        , String ville
        , String pays
        , String type
        , String portable
        , String telephone
        , String adresse
        , String email

) { }
