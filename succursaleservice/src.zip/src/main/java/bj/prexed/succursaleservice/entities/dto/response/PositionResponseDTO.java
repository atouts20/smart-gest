package bj.prexed.succursaleservice.entities.dto.response;

public class PositionResponseDTO {
}
