package bj.prexed.succursaleservice.records.request;

public record AgenceRequestDTO(String refAgence, String lblAgence, String telephone, String adresse, String division, String ktierId) {
}
