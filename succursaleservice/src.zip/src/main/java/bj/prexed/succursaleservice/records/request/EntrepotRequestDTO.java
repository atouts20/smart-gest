package bj.prexed.succursaleservice.records.request;

import bj.prexed.succursaleservice.entities.Agence;

public record EntrepotRequestDTO(String reference, String lblEntrepot, String telephone, String type, boolean initialised, Agence agence) {
}
