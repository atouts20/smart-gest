package bj.prexed.succursaleservice.enums;

public enum TypeAgence {
    Mobile
    ,Shop
    ,Boutique
}
