package bj.prexed.succursaleservice.records.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class EntiteResponseDTO {
        private String id; private 
          String sigle
        ; private  String raisociale
        ; private  String email
        ; private  boolean enabled
        ; private  String verificaToken
        ; private  boolean deleted
        ; private  String urllogo
        ; private  String slogan
        ; private  String domaineweb;
}
