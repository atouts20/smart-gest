package bj.prexed.succursaleservice.enums;

public enum TypeStructure {
    Agroalimentaire
    ,GSM
    ,Brasserie
    ,Supermarché
}
