package bj.prexed.succursaleservice.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;


@Entity
@Data
@AllArgsConstructor @NoArgsConstructor @Builder
public class Division {

    @Id
    private String id;

    @Column(nullable = false)
    private String lblDivision;

    @Column(columnDefinition = "text")
    private String description;

    @ManyToOne
    private Succursale succursale;

    @OneToMany(mappedBy = "division")
    private Set<Agence> agences = new HashSet<>();
}
