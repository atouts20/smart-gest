package bj.prexed.succursaleservice.entities.dto.resquest;

public class EntrepotRequestDTO {
}
