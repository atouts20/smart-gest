package bj.prexed.succursaleservice.mappers;

import bj.prexed.succursaleservice.entities.Agence;
import bj.prexed.succursaleservice.records.request.AgenceRequestDTO;
import bj.prexed.succursaleservice.records.response.AgenceResponseDTO;
import org.springframework.data.domain.Page;

import java.util.List;

public interface EntityMapper<D,E>{

   /* E toEntity(D dto);
    D toDto(E entity);
    List<E> toEntity(List<D> dtoList);
    List<D> toDto(List<E> entityList);

    Page<E> toEntityPage(Page<D> dtoPage);



    Page<D>toDtoPage(Page<E> entityPage);*/

}