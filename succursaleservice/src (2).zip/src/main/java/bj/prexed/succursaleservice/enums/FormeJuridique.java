package bj.prexed.succursaleservice.enums;

public enum FormeJuridique {
    ETS
    , SARL
    , SA
}
