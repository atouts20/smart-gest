package bj.prexed.succursaleservice.servicesImpl;

import bj.prexed.succursaleservice.entities.Succursale;
import bj.prexed.succursaleservice.entities.Division;
import bj.prexed.succursaleservice.entities.Succursale;
import bj.prexed.succursaleservice.exception.ResourceNotFoundException;
import bj.prexed.succursaleservice.mappers.DivisionMapper;
import bj.prexed.succursaleservice.records.request.DivisionRequestDTO;
import bj.prexed.succursaleservice.records.response.DivisionResponseDTO;
import bj.prexed.succursaleservice.repositories.DivisionRepository;
import bj.prexed.succursaleservice.services.DivisionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
@Transactional
@Slf4j
public class DivisionImpl  implements DivisionService {
    private final DivisionRepository divisionRepository;
    private final DivisionMapper divisionMapper;

    public DivisionImpl(DivisionRepository divisionRepository, DivisionMapper divisionMapper) {
        this.divisionRepository = divisionRepository;
        this.divisionMapper = divisionMapper;
    }



    @Override
    public DivisionResponseDTO add(DivisionRequestDTO resquest) {
        return divisionMapper.toDtoR(divisionRepository.save(divisionMapper.toEntity (resquest)));
    }



    @Override
    public Page<Division> all ( Succursale s, Pageable page ) {
        return divisionRepository.findBySuccursale (s, page );
    }

    @Override
    public DivisionResponseDTO one ( String id ) {
        Division e = divisionRepository.findById(id).orElseThrow(() -> new RuntimeException(String.format("Cannot Find Expense by ID %s", id)));
        return divisionMapper.toDtoR ( e );
    }

    @Override
    public DivisionResponseDTO set ( String id , Division division ) {
        Division  e = divisionRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException ("Division", id));
        return divisionMapper.toDtoR(divisionRepository.save(divisionMapper.toUpdate(division,e)));
    }
}
